<?php

namespace SampleBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SampleBundle extends Bundle
{
}
